package com.board_of_ads.models.dto.order;

public enum DeliveryStatus {
    CANCELED,
    WAITING,
    IN_PROCESS,
    DONE
}

package com.board_of_ads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardOfAdsApplicationTests {

    @Test
    void contextLoads() {
    }

}
